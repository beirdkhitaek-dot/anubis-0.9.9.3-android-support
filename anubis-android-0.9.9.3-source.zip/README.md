# Anubis 0.9.9.3 - Android port

Unofficial port of **Anubis Beta 0.9.9.3** (Minecraft 1.21.11, Fabric) that starts on Android launchers
such as Zalith. It adds the arm64 ImGui library and the Android input and file-picker code that the
developers removed after 0.9.9.1. It is **not** an official build and is not signed.

Anubis is GPL-3.0 (see `LICENSE-Anubis-GPL3`).

## Put it on GitHub and build it

1. On github.com create a new **empty** repository (no README, no .gitignore).
2. Open it in a Codespace (Code > Codespaces > Create).
3. Drag `anubis-android-0.9.9.3-source.zip` into the Codespace file list on the left.
4. In the Codespace terminal run:

   ```
   unzip -o anubis-android-0.9.9.3-source.zip
   rm anubis-android-0.9.9.3-source.zip
   git add -A
   git commit -m "Anubis 0.9.9.3 Android port"
   git push
   ```

   If `unzip` is missing, use `python3 -m zipfile -e anubis-android-0.9.9.3-source.zip .` instead.
5. Open the **Actions** tab. The "Build and release" run starts by itself and takes about a minute.
6. When it is green, open **Releases** on the right of the repo page. The jar is attached there as
   `Anubis_Beta_0.9.9.3-android.jar`.

If the run does not start, open Actions > "Build and release" > Run workflow.

## Making a new release later

A release can only be made once per version. To publish an update:

1. Change the number in `VERSION` (for example `0.9.9.3-android.2`).
2. Change the words in `UPDATE_NAME` (for example `Spotify HUD fix`).
3. Commit and push. The release title becomes `Anubis <VERSION> - <UPDATE_NAME>` and the jar is named
   `Anubis_Beta_<VERSION>.jar`. The version also shows in the mod list in game.

## How it works

The Fabric and Minecraft download servers are needed to compile all of Anubis from scratch, so this
repo does not recompile everything. `scripts/build.py` takes the official jar in `base/`, adds the
Android files in `overlay/`, builds `overlay-src/OfficialBuild.java` with javac, removes the signature,
and writes the version. `reference-src/` holds readable decompiled source of the result for study.
It uses Minecraft's internal `class_1234` names and is not compiled by the workflow.
