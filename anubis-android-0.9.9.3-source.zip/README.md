# Anubis 0.9.9.3 - Android port

Unofficial port of **Anubis Beta 0.9.9.3** (Minecraft 1.21.11, Fabric) that starts on Android launchers
such as Zalith. It adds the arm64 ImGui library and the Android input and file-picker code that the
developers removed after 0.9.9.1. It is **not** an official build and is not signed.

Anubis is GPL-3.0 (see `LICENSE-Anubis-GPL3`).

## Put it on GitHub and build it

1. On github.com create a new **empty** repository (no README, no .gitignore).
2. Open it in a Codespace (Code > Codespaces > Create).
3. Drag `anubis-android-0.9.9.3-source.zip` into the Codespace file list on the left.
4. In the Codespace terminal run:

   ```
   unzip -o anubis-android-0.9.9.3-source.zip
   rm anubis-android-0.9.9.3-source.zip
   git add -A
   git commit -m "Anubis 0.9.9.3 Android port"
   git push
   ```

   If `unzip` is missing, use `python3 -m zipfile -e anubis-android-0.9.9.3-source.zip .` instead.
5. Open the **Actions** tab. The "Build and release" run starts by itself and takes about a minute.
6. When it is green, open **Releases** on the right of the repo page. The jar is attached there as
   `Anubis_Beta_0.9.9.3-android.jar`.

If the run does not start, open Actions > "Build and release" > Run workflow.

## Spotify HUD on Android

The Spotify app on a phone cannot be read by a mod, so on Android the HUD asks a website instead.
Turn on the Spotify HUD module in Anubis. It shows "Spotify setup needed". Then, in your phone's browser,
open `127.0.0.1:8888` (type it exactly). The page offers two ways:

**Free way (Last.fm, no Premium needed)**
1. Make a free account at last.fm. In Last.fm open Settings > Applications and connect **Spotify**.
2. Open `last.fm/api/account/create`, make an API account (any name) and copy the **API key**.
3. On the `127.0.0.1:8888` page enter your Last.fm username and the API key, then press **Save**.

The HUD then shows the song, artist and cover of what Spotify is playing. Last.fm does not say how long the
song is or where you are in it, so there is no progress bar or synced lyrics, and play/pause/skip are not
available. The song can appear a few seconds late.

**Spotify's own API (needs Premium)**
Spotify only lets developer apps use its Web API when the app's owner has Premium. If you have Premium:
create an app at developer.spotify.com/dashboard, add the Redirect URI the page shows, tick **Web API**,
paste the app's **Client ID** into the page and press **Log in with Spotify**. This gives the progress bar,
lyrics and, with Premium, play/pause/next/previous. If Spotify refuses, the HUD says "Spotify blocked the
app" and the setup page opens again so you can use Last.fm instead.

Your details are saved in `config/anubis-spotify-android.json` (Last.fm name and key, or the Spotify Client
ID and a login token, never a password). Delete that file to start over.

## Making a new release later

A release can only be made once per version. To publish an update:

1. Change the number in `VERSION` (for example `0.9.9.3-android.2`).
2. Change the words in `UPDATE_NAME` (for example `Spotify HUD fix`).
3. Commit and push. The release title becomes `Anubis <VERSION> - <UPDATE_NAME>` and the jar is named
   `Anubis_Beta_<VERSION>.jar`. The version also shows in the mod list in game.

## How it works

The Fabric and Minecraft download servers are needed to compile all of Anubis from scratch, so this
repo does not recompile everything. `scripts/build.py` takes the official jar in `base/`, adds the
Android files in `overlay/`, builds `overlay-src/OfficialBuild.java` with javac, removes the signature,
and writes the version. `reference-src/` holds readable decompiled source of the result for study.
It uses Minecraft's internal `class_1234` names and is not compiled by the workflow.
