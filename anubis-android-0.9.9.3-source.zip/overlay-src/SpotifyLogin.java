package net.anubis.client.util.spotify;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Spotify login for Android, where the Spotify app cannot be read directly.
 * The user opens http://127.0.0.1:8888 in the phone's browser, pastes their Spotify Client ID and logs in
 * (Authorization Code with PKCE, so no client secret is stored). Only a refresh token is saved.
 */
final class SpotifyLogin {
   static final int PORT = Integer.getInteger("anubis.spotify.port", 8888);
   static final String REDIRECT = "http://127.0.0.1:" + PORT + "/callback";
   static final String ADDRESS = "127.0.0.1:" + PORT;
   private static final String AUTHORIZE = System.getProperty("anubis.spotify.authorizeUrl", "https://accounts.spotify.com/authorize");
   private static final String TOKEN = System.getProperty("anubis.spotify.tokenUrl", "https://accounts.spotify.com/api/token");
   private static final String SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing";
   private static final SecureRandom RANDOM = new SecureRandom();

   private final Path file = configFile();
   private volatile String clientId = "";
   private volatile String refreshToken = "";
   private volatile String accessToken = "";
   private volatile long accessExpiresAt;
   private volatile String message = "";
   private String verifier;
   private String state;
   private ServerSocket server;
   private volatile boolean closed;
   private boolean loaded;

   private static Path configFile() {
      String override = System.getProperty("anubis.spotify.config");
      if (override != null && !override.isBlank()) {
         return Paths.get(override);
      }
      try {
         Class<?> loader = Class.forName("net.fabricmc.loader.api.FabricLoader");
         Object instance = loader.getMethod("getInstance").invoke(null);
         Path dir = (Path)loader.getMethod("getConfigDir").invoke(instance);
         return dir.resolve("anubis-spotify-android.json");
      } catch (ReflectiveOperationException | RuntimeException | LinkageError var3) {
         return Paths.get("config", "anubis-spotify-android.json");
      }
   }

   synchronized void start() {
      if (!this.loaded) {
         this.loaded = true;
         this.load();
      }
      if (this.server == null && !this.closed && !this.hasRefreshToken()) {
         try {
            ServerSocket socket = new ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"));
            this.server = socket;
            Thread thread = new Thread(() -> this.serve(socket), "Anubis-Spotify-Login");
            thread.setDaemon(true);
            thread.start();
         } catch (IOException var3) {
            this.message = "Port " + PORT + " is busy: " + var3.getMessage();
         }
      }
   }

   synchronized void close() {
      this.closed = true;
      this.stopServer();
   }

   private synchronized void stopServer() {
      if (this.server != null) {
         try {
            this.server.close();
         } catch (IOException var2) {
         }
         this.server = null;
      }
   }

   boolean hasClientId() {
      return !this.clientId.isEmpty();
   }

   boolean hasRefreshToken() {
      return !this.refreshToken.isEmpty();
   }

   String message() {
      return this.message;
   }

   /** Returns a usable access token, refreshing it when needed, or null when the user still has to log in. */
   String accessToken() throws IOException {
      if (!this.hasRefreshToken()) {
         return null;
      } else {
         if (this.accessToken.isEmpty() || System.currentTimeMillis() > this.accessExpiresAt - 30000L) {
            this.refresh();
         }
         return this.accessToken.isEmpty() ? null : this.accessToken;
      }
   }

   void rejectAccessToken() {
      this.accessToken = "";
      this.accessExpiresAt = 0L;
   }

   private void refresh() throws IOException {
      SpotifyHttp.Reply reply = SpotifyHttp.call(
         "POST",
         TOKEN,
         null,
         form("grant_type", "refresh_token", "refresh_token", this.refreshToken, "client_id", this.clientId),
         "application/x-www-form-urlencoded",
         6000
      );
      if (reply.ok()) {
         this.takeTokens(reply);
      } else if (reply.status() == 400 || reply.status() == 401) {
         this.refreshToken = "";
         this.accessToken = "";
         this.message = "Spotify login expired, log in again";
         this.save();
         this.start();
      } else {
         throw new IOException("Spotify token refresh failed (" + reply.status() + ")");
      }
   }

   private void takeTokens(SpotifyHttp.Reply reply) throws IOException {
      Map<String, Object> json = JsonLite.obj(JsonLite.parse(reply.text()));
      String access = JsonLite.str(json.get("access_token"));
      if (access.isEmpty()) {
         throw new IOException("Spotify sent no access token");
      }
      this.accessToken = access;
      this.accessExpiresAt = System.currentTimeMillis() + Math.max(60L, JsonLite.num(json.get("expires_in"))) * 1000L;
      String refresh = JsonLite.str(json.get("refresh_token"));
      if (!refresh.isEmpty()) {
         this.refreshToken = refresh;
      }
      this.message = "";
      this.save();
   }

   private void load() {
      try {
         if (Files.isRegularFile(this.file)) {
            Map<String, Object> json = JsonLite.obj(JsonLite.parse(Files.readString(this.file, StandardCharsets.UTF_8)));
            this.clientId = JsonLite.str(json.get("client_id")).strip();
            this.refreshToken = JsonLite.str(json.get("refresh_token")).strip();
         }
      } catch (IOException | RuntimeException var2) {
         this.message = "Could not read " + this.file.getFileName();
      }
   }

   private synchronized void save() {
      try {
         if (this.file.getParent() != null) {
            Files.createDirectories(this.file.getParent());
         }
         String json = "{\n  \"client_id\": " + JsonLite.quote(this.clientId) + ",\n  \"refresh_token\": " + JsonLite.quote(this.refreshToken) + "\n}\n";
         Files.writeString(this.file, json, StandardCharsets.UTF_8);
      } catch (IOException var2) {
         this.message = "Could not save " + this.file.getFileName() + ": " + var2.getMessage();
      }
   }

   // ---- tiny local web server -------------------------------------------------------------------------------------

   private void serve(ServerSocket socket) {
      while (!this.closed && !socket.isClosed()) {
         try (Socket client = socket.accept()) {
            client.setSoTimeout(4000);
            this.handle(client);
         } catch (IOException var6) {
            if (socket.isClosed()) {
               return;
            }
         } catch (RuntimeException var7) {
            this.message = "Login page error: " + var7;
         }
      }
   }

   private void handle(Socket client) throws IOException {
      BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.ISO_8859_1));
      String request = in.readLine();
      if (request == null) {
         return;
      }
      for (String line = in.readLine(); line != null && !line.isEmpty(); line = in.readLine()) {
      }
      String[] parts = request.split(" ");
      if (parts.length < 2 || !parts[0].equals("GET")) {
         this.reply(client, 405, "text/plain", "Method not allowed", null);
         return;
      }
      String target = parts[1];
      int q = target.indexOf(63);
      String path = q < 0 ? target : target.substring(0, q);
      Map<String, String> query = parseQuery(q < 0 ? "" : target.substring(q + 1));
      switch (path) {
         case "/" -> this.reply(client, 200, "text/html", this.homePage(), null);
         case "/start" -> this.begin(client, query);
         case "/callback" -> this.callback(client, query);
         case "/logout" -> {
            this.refreshToken = "";
            this.accessToken = "";
            this.save();
            this.reply(client, 302, "text/plain", "", "/");
         }
         default -> this.reply(client, 404, "text/plain", "Not found", null);
      }
   }

   private void begin(Socket client, Map<String, String> query) throws IOException {
      String id = query.getOrDefault("client_id", this.clientId).strip();
      if (!id.matches("[A-Za-z0-9]{16,64}")) {
         this.reply(client, 200, "text/html", page("Client ID looks wrong", "<p>The Client ID should be 32 letters and numbers.</p><p><a href=\"/\">Back</a></p>"), null);
         return;
      }
      this.clientId = id;
      this.save();
      byte[] raw = new byte[64];
      RANDOM.nextBytes(raw);
      this.verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
      byte[] hash;
      try {
         hash = MessageDigest.getInstance("SHA-256").digest(this.verifier.getBytes(StandardCharsets.US_ASCII));
      } catch (java.security.NoSuchAlgorithmException var8) {
         throw new IOException(var8);
      }
      byte[] stateBytes = new byte[16];
      RANDOM.nextBytes(stateBytes);
      this.state = Base64.getUrlEncoder().withoutPadding().encodeToString(stateBytes);
      String url = AUTHORIZE
         + "?response_type=code&client_id=" + enc(id)
         + "&scope=" + enc(SCOPES)
         + "&redirect_uri=" + enc(REDIRECT)
         + "&state=" + enc(this.state)
         + "&code_challenge_method=S256&code_challenge=" + Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
      this.reply(client, 302, "text/plain", "", url);
   }

   private void callback(Socket client, Map<String, String> query) throws IOException {
      String error = query.get("error");
      if (error != null) {
         this.message = "Spotify said: " + error;
         this.reply(client, 200, "text/html", page("Login cancelled", "<p>" + esc(error) + "</p><p><a href=\"/\">Try again</a></p>"), null);
         return;
      }
      String code = query.get("code");
      if (code == null || this.state == null || !this.state.equals(query.get("state")) || this.verifier == null) {
         this.reply(client, 400, "text/html", page("Login failed", "<p>That login link was not valid. <a href=\"/\">Start again</a></p>"), null);
         return;
      }
      SpotifyHttp.Reply reply = SpotifyHttp.call(
         "POST",
         TOKEN,
         null,
         form("grant_type", "authorization_code", "code", code, "redirect_uri", REDIRECT, "client_id", this.clientId, "code_verifier", this.verifier),
         "application/x-www-form-urlencoded",
         8000
      );
      this.verifier = null;
      this.state = null;
      if (!reply.ok()) {
         this.message = "Spotify login failed (" + reply.status() + ")";
         this.reply(client, 200, "text/html", page("Login failed", "<p>Spotify answered " + reply.status() + ". Check the Client ID and the Redirect URI. <a href=\"/\">Try again</a></p>"), null);
         return;
      }
      this.takeTokens(reply);
      this.reply(client, 200, "text/html", page("Spotify connected", "<p>You can go back to Minecraft. The Spotify HUD will start showing your music.</p>"), null);
      this.stopServerLater();
   }

   private void stopServerLater() {
      Thread thread = new Thread(() -> {
         try {
            Thread.sleep(1500L);
         } catch (InterruptedException var2) {
            return;
         }
         this.stopServer();
      }, "Anubis-Spotify-Login-Stop");
      thread.setDaemon(true);
      thread.start();
   }

   private String homePage() {
      if (this.hasRefreshToken()) {
         return page("Spotify connected", "<p>Already logged in.</p><p><a class=\"b\" href=\"/logout\">Log out</a></p>");
      } else {
         String id = esc(this.clientId);
         return page(
            "Connect Spotify",
            "<ol><li>Open <b>developer.spotify.com/dashboard</b> and create an app.</li>"
               + "<li>Add this Redirect URI: <code>" + esc(REDIRECT) + "</code></li>"
               + "<li>Tick <b>Web API</b>, save, then copy the app's <b>Client ID</b>.</li></ol>"
               + "<form action=\"/start\" method=\"get\"><input name=\"client_id\" value=\"" + id + "\" placeholder=\"Client ID\" autocomplete=\"off\">"
               + "<button class=\"b\" type=\"submit\">Log in with Spotify</button></form>"
         );
      }
   }

   private void reply(Socket client, int status, String type, String body, String location) throws IOException {
      byte[] data = body.getBytes(StandardCharsets.UTF_8);
      String reason = switch (status) {
         case 200 -> "OK";
         case 302 -> "Found";
         case 400 -> "Bad Request";
         case 404 -> "Not Found";
         default -> "Error";
      };
      StringBuilder head = new StringBuilder("HTTP/1.1 " + status + " " + reason + "\r\n");
      head.append("Content-Type: ").append(type).append("; charset=utf-8\r\n");
      head.append("Content-Length: ").append(data.length).append("\r\n");
      head.append("Cache-Control: no-store\r\nConnection: close\r\n");
      if (location != null) {
         head.append("Location: ").append(location).append("\r\n");
      }
      head.append("\r\n");
      OutputStream out = client.getOutputStream();
      out.write(head.toString().getBytes(StandardCharsets.ISO_8859_1));
      out.write(data);
      out.flush();
   }

   private static String page(String title, String body) {
      return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
         + "<title>" + esc(title) + "</title><style>body{font-family:sans-serif;background:#121212;color:#eee;max-width:34em;margin:1.2em auto;padding:0 1em;line-height:1.5}"
         + "code{background:#222;padding:.1em .3em;word-break:break-all}input{width:100%;box-sizing:border-box;padding:.7em;margin:.6em 0;font-size:1em}"
         + ".b{display:inline-block;background:#1db954;color:#000;border:0;padding:.8em 1.2em;border-radius:2em;font-size:1em;text-decoration:none}a{color:#1db954}</style>"
         + "</head><body><h2>" + esc(title) + "</h2>" + body + "</body></html>";
   }

   private static Map<String, String> parseQuery(String query) {
      Map<String, String> map = new HashMap<>();
      for (String pair : query.split("&")) {
         if (!pair.isEmpty()) {
            int eq = pair.indexOf(61);
            String key = eq < 0 ? pair : pair.substring(0, eq);
            String value = eq < 0 ? "" : pair.substring(eq + 1);
            map.put(URLDecoder.decode(key, StandardCharsets.UTF_8), URLDecoder.decode(value, StandardCharsets.UTF_8));
         }
      }
      return map;
   }

   private static String form(String... pairs) {
      StringBuilder out = new StringBuilder();
      for (int i = 0; i + 1 < pairs.length; i += 2) {
         if (out.length() > 0) {
            out.append('&');
         }
         out.append(enc(pairs[i])).append('=').append(enc(pairs[i + 1]));
      }
      return out.toString();
   }

   private static String enc(String value) {
      return URLEncoder.encode(value, StandardCharsets.UTF_8);
   }

   private static String esc(String value) {
      return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
   }
}
