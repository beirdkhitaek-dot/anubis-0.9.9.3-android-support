package net.anubis.client.util.spotify;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Spotify for Android launchers: reads the playback state from Spotify's web API instead of the desktop app.
 * Showing the track needs any Spotify account; play/pause/skip need Spotify Premium.
 */
final class AndroidSpotify extends ScriptedPlayer {
   private static final String API = System.getProperty("anubis.spotify.api", "https://api.spotify.com/v1");
   private static final long PLAYING_GAP_MS = 2000L;
   private static final long PAUSED_GAP_MS = 3000L;
   private static final long ART_RETRY_MS = 10000L;
   private static final int TIMEOUT_MS = 5000;

   private final SpotifyLogin login = new SpotifyLogin();
   private long nextFetchAt;
   private ScriptedPlayer.Reading cached;
   private long cachedAt;
   private boolean lastPlaying;
   private String artUrl = "";
   private byte[] artBytes;
   private int artVersion;
   private long artRetryAt;

   @Override
   protected ScriptedPlayer.Reading read() throws IOException {
      this.login.start();
      String token = this.login.accessToken();
      if (token == null) {
         this.cached = null;
         return this.setup();
      }
      long now = System.currentTimeMillis();
      if (now < this.nextFetchAt) {
         return this.extrapolate(now);
      }
      SpotifyHttp.Reply reply = SpotifyHttp.call("GET", API + "/me/player?additional_types=episode", token, null, null, TIMEOUT_MS);
      if (reply.status() == 401) {
         // The access token was revoked or expired early: get a fresh one and try once more.
         this.login.rejectAccessToken();
         token = this.login.accessToken();
         if (token == null) {
            this.cached = null;
            return this.setup();
         }
         reply = SpotifyHttp.call("GET", API + "/me/player?additional_types=episode", token, null, null, TIMEOUT_MS);
      }
      switch (reply.status()) {
         case 200:
            return this.parse(reply.text(), now);
         case 204:
            this.cached = null;
            this.nextFetchAt = now + PAUSED_GAP_MS;
            return null;
         case 401:
            this.login.rejectAccessToken();
            this.nextFetchAt = now + 500L;
            throw new IOException("Spotify login was rejected, retrying");
         case 429:
            long wait = 5L;
            try {
               wait = Long.parseLong(reply.retryAfter() == null ? "5" : reply.retryAfter().strip());
            } catch (NumberFormatException var8) {
            }
            this.nextFetchAt = now + Math.max(1L, Math.min(wait, 60L)) * 1000L;
            return this.extrapolate(now);
         default:
            this.nextFetchAt = now + 5000L;
            throw new IOException("Spotify API answered " + reply.status());
      }
   }

   private ScriptedPlayer.Reading setup() {
      String detail = this.login.message().isEmpty() ? "Open " + SpotifyLogin.ADDRESS + " in your browser" : this.login.message();
      String title = this.login.hasClientId() ? "Spotify login needed" : "Spotify setup needed";
      return new ScriptedPlayer.Reading(MediaSession.PlaybackState.PAUSED, title, detail, "", 0L, 0L, "");
   }

   private ScriptedPlayer.Reading parse(String body, long now) throws IOException {
      Map<String, Object> player = JsonLite.obj(JsonLite.parse(body));
      Map<String, Object> item = JsonLite.obj(player.get("item"));
      boolean playing = JsonLite.bool(player.get("is_playing"));
      this.nextFetchAt = now + (playing ? PLAYING_GAP_MS : PAUSED_GAP_MS);
      if (item.isEmpty()) {
         this.cached = null;
         return null;
      }
      boolean episode = "episode".equals(JsonLite.str(item.get("type")));
      Map<String, Object> show = JsonLite.obj(item.get("show"));
      Map<String, Object> album = JsonLite.obj(item.get("album"));
      List<String> names = new ArrayList<>();
      for (Object artist : JsonLite.arr(item.get("artists"))) {
         String name = JsonLite.str(JsonLite.obj(artist).get("name"));
         if (!name.isEmpty()) {
            names.add(name);
         }
      }
      String artist = episode ? JsonLite.str(show.get("publisher")) : String.join(", ", names);
      String albumName = episode ? JsonLite.str(show.get("name")) : JsonLite.str(album.get("name"));
      List<Object> images = episode ? JsonLite.arr(item.get("images")) : JsonLite.arr(album.get("images"));
      if (images.isEmpty() && episode) {
         images = JsonLite.arr(show.get("images"));
      }
      this.updateArt(pickImage(images), now);
      this.lastPlaying = playing;
      this.cached = new ScriptedPlayer.Reading(
         playing ? MediaSession.PlaybackState.PLAYING : MediaSession.PlaybackState.PAUSED,
         JsonLite.str(item.get("name")),
         artist,
         albumName,
         JsonLite.num(item.get("duration_ms")),
         JsonLite.num(player.get("progress_ms")),
         ""
      );
      this.cachedAt = now;
      return this.cached;
   }

   private ScriptedPlayer.Reading extrapolate(long now) {
      ScriptedPlayer.Reading reading = this.cached;
      if (reading == null) {
         return null;
      }
      long position = reading.positionMs();
      if (reading.state() == MediaSession.PlaybackState.PLAYING) {
         position += Math.max(0L, now - this.cachedAt);
      }
      if (reading.durationMs() > 0L) {
         position = Math.min(position, reading.durationMs());
      }
      return new ScriptedPlayer.Reading(reading.state(), reading.title(), reading.artist(), reading.album(), reading.durationMs(), position, "");
   }

   /** Picks the smallest image that is at least 256 wide, or the largest one when none is. */
   private static String pickImage(List<Object> images) {
      String best = "";
      long bestWidth = Long.MAX_VALUE;
      String largest = "";
      long largestWidth = -1L;
      for (Object entry : images) {
         Map<String, Object> image = JsonLite.obj(entry);
         String url = JsonLite.str(image.get("url"));
         long width = JsonLite.num(image.get("width"));
         if (url.isEmpty()) {
            continue;
         }
         if (width >= 256L && width < bestWidth) {
            best = url;
            bestWidth = width;
         }
         if (width > largestWidth) {
            largest = url;
            largestWidth = width;
         }
      }
      return best.isEmpty() ? largest : best;
   }

   private void updateArt(String url, long now) {
      if (!url.equals(this.artUrl) || this.artBytes == null && !url.isEmpty() && now >= this.artRetryAt) {
         this.artUrl = url;
         byte[] bytes = null;
         if (!url.isEmpty()) {
            try {
               bytes = SpotifyHttp.download(url, 3000);
            } catch (IOException var6) {
               bytes = null;
            }
            if (bytes == null) {
               this.artRetryAt = now + ART_RETRY_MS;
            }
         }
         if (bytes != null || this.artBytes != null) {
            this.artBytes = bytes;
            this.artVersion++;
         }
      }
   }

   @Override
   public MediaSession.Snapshot poll() {
      MediaSession.Snapshot snapshot = super.poll();
      if (snapshot == null) {
         return null;
      }
      return new MediaSession.Snapshot(
         snapshot.title(),
         snapshot.artist(),
         snapshot.album(),
         snapshot.durationMs(),
         snapshot.positionMs(),
         snapshot.sampledAtMs(),
         snapshot.state(),
         snapshot.rate(),
         this.artBytes,
         this.artBytes == null ? "" : "image",
         this.artVersion
      );
   }

   @Override
   protected boolean send(ScriptedPlayer.Command command) throws IOException {
      String token = this.login.accessToken();
      if (token == null) {
         return false;
      }
      String method = "POST";
      String path;
      switch (command) {
         case PLAY_PAUSE -> {
            method = "PUT";
            path = this.lastPlaying ? "/me/player/pause" : "/me/player/play";
         }
         case NEXT -> path = "/me/player/next";
         default -> path = "/me/player/previous";
      }
      SpotifyHttp.Reply reply = SpotifyHttp.call(method, API + path, token, null, null, TIMEOUT_MS);
      if (reply.ok()) {
         if (command == ScriptedPlayer.Command.PLAY_PAUSE) {
            this.lastPlaying = !this.lastPlaying;
         }
         this.nextFetchAt = 0L;
         return true;
      } else if (reply.status() == 403) {
         throw new IOException("Spotify Premium is needed to control playback");
      } else if (reply.status() == 404) {
         return false;
      } else {
         throw new IOException("Spotify API answered " + reply.status());
      }
   }

   @Override
   public void close() {
      super.close();
      this.login.close();
   }
}
