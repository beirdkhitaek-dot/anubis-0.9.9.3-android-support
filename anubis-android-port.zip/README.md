# Anubis Android port

Unofficial Android port of **Anubis** (Minecraft 1.21.11, Fabric) that starts on Android launchers such as
Zalith. It adds the arm64 ImGui library, the Android input and file-picker code, and a Spotify HUD that works
on Android. It is **not** an official build and is not signed.

**Android port by Chukl.** Anubis is made by its original developers. Anubis is GPL-3.0 (see `LICENSE-Anubis-GPL3`).

## Updating to a new Anubis version (the easy way)

1. Keep the GitHub repository **private** (the official jar must not be public).
2. In the repo open the `base` folder > **Add file > Upload files** and upload the new official jar.
   You can delete the old jar from `base`, but you do not have to: the newest version is used.
3. Commit. GitHub builds the Android jar by itself (Actions tab, about a minute) and publishes it under
   **Releases** as `Anubis_<version>-android.<n>.jar`, with a title like `Anubis 1.0-android.1 - Android port by Chukl`.

If the run turns red with "this Anubis update changed parts that the Android port depends on", the update
changed something the port needs. Nothing is published. The port has to be fixed first.

## Same Anubis version, new port fix

A release can only be made once per version. Edit the file `PORT_REVISION` in the repo root (create it if it
does not exist) and change the number (for example `2`). Optionally write the update name in `UPDATE_NAME`.
Commit, and the new release is named `<official version>-android.<PORT_REVISION>`.

## Spotify HUD on Android

The Spotify app on a phone cannot be read by a mod, so on Android the HUD asks a website instead.
Turn on the Spotify HUD module in Anubis. It shows "Spotify setup needed". Then, in your phone's browser,
open `127.0.0.1:8888` (type it exactly). The page offers two ways:

**Free way (Last.fm, no Premium needed)**
1. Make a free account at last.fm. In Last.fm open Settings > Applications and connect **Spotify**.
2. Open `last.fm/api/account/create`, make an API account (any name) and copy the **API key**.
3. On the `127.0.0.1:8888` page enter your Last.fm username and the API key, then press **Save**.

The HUD then shows the song, artist and cover of what Spotify is playing. Last.fm does not say how long the
song is or where you are in it, so there is no progress bar or synced lyrics, and play/pause/skip are not
available. The song can appear a few seconds late.

**Spotify's own API (needs Premium)**
Spotify only lets developer apps use its Web API when the app's owner has Premium. If you have Premium:
create an app at developer.spotify.com/dashboard, add the Redirect URI the page shows, tick **Web API**,
paste the app's **Client ID** into the page and press **Log in with Spotify**.

Your details are saved in `config/anubis-spotify-android.json` (never a password). Delete it to start over.

## How it works

`scripts/build.py` takes the official jar in `base/`, checks that the inner parts the port depends on are
unchanged (`compat/base-hashes.json`), adds the Android files in `overlay/`, builds `overlay-src/` with javac,
removes the signature, writes the version and the credit, and writes `dist/`.
