package net.anubis.client.util.spotify;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Small JSON reader so the Android Spotify player needs no extra libraries. */
final class JsonLite {
   private final String text;
   private int pos;

   private JsonLite(String text) {
      this.text = text;
   }

   static Object parse(String text) throws IOException {
      JsonLite reader = new JsonLite(text == null ? "" : text);
      reader.skip();
      Object value = reader.value();
      reader.skip();
      if (reader.pos != reader.text.length()) {
         throw new IOException("unexpected data after JSON value");
      }
      return value;
   }

   @SuppressWarnings("unchecked")
   static Map<String, Object> obj(Object value) {
      return value instanceof Map ? (Map<String, Object>)value : Map.of();
   }

   @SuppressWarnings("unchecked")
   static List<Object> arr(Object value) {
      return value instanceof List ? (List<Object>)value : List.of();
   }

   static String str(Object value) {
      return value instanceof String s ? s : "";
   }

   static long num(Object value) {
      return value instanceof Number n ? n.longValue() : 0L;
   }

   static boolean bool(Object value) {
      return value instanceof Boolean b && b;
   }

   static String quote(String value) {
      StringBuilder out = new StringBuilder("\"");
      for (int i = 0; i < value.length(); i++) {
         char c = value.charAt(i);
         switch (c) {
            case '"' -> out.append("\\\"");
            case '\\' -> out.append("\\\\");
            case '\n' -> out.append("\\n");
            case '\r' -> out.append("\\r");
            case '\t' -> out.append("\\t");
            default -> {
               if (c < 0x20) {
                  out.append(String.format("\\u%04x", (int)c));
               } else {
                  out.append(c);
               }
            }
         }
      }
      return out.append('"').toString();
   }

   private void skip() {
      while (this.pos < this.text.length() && Character.isWhitespace(this.text.charAt(this.pos))) {
         this.pos++;
      }
   }

   private char peek() throws IOException {
      if (this.pos >= this.text.length()) {
         throw new IOException("unexpected end of JSON");
      }
      return this.text.charAt(this.pos);
   }

   private Object value() throws IOException {
      char c = this.peek();
      if (c == '{') {
         return this.object();
      } else if (c == '[') {
         return this.array();
      } else if (c == '"') {
         return this.string();
      } else if (this.text.startsWith("true", this.pos)) {
         this.pos += 4;
         return Boolean.TRUE;
      } else if (this.text.startsWith("false", this.pos)) {
         this.pos += 5;
         return Boolean.FALSE;
      } else if (this.text.startsWith("null", this.pos)) {
         this.pos += 4;
         return null;
      } else {
         return this.number();
      }
   }

   private Map<String, Object> object() throws IOException {
      Map<String, Object> map = new LinkedHashMap<>();
      this.pos++;
      this.skip();
      if (this.peek() == '}') {
         this.pos++;
         return map;
      }
      while (true) {
         this.skip();
         String key = this.string();
         this.skip();
         if (this.peek() != ':') {
            throw new IOException("expected ':' in JSON object");
         }
         this.pos++;
         this.skip();
         map.put(key, this.value());
         this.skip();
         char c = this.peek();
         this.pos++;
         if (c == '}') {
            return map;
         }
         if (c != ',') {
            throw new IOException("expected ',' in JSON object");
         }
      }
   }

   private List<Object> array() throws IOException {
      List<Object> list = new ArrayList<>();
      this.pos++;
      this.skip();
      if (this.peek() == ']') {
         this.pos++;
         return list;
      }
      while (true) {
         this.skip();
         list.add(this.value());
         this.skip();
         char c = this.peek();
         this.pos++;
         if (c == ']') {
            return list;
         }
         if (c != ',') {
            throw new IOException("expected ',' in JSON array");
         }
      }
   }

   private String string() throws IOException {
      if (this.peek() != '"') {
         throw new IOException("expected string in JSON");
      }
      this.pos++;
      StringBuilder out = new StringBuilder();
      while (true) {
         char c = this.peek();
         this.pos++;
         if (c == '"') {
            return out.toString();
         }
         if (c != '\\') {
            out.append(c);
            continue;
         }
         char e = this.peek();
         this.pos++;
         switch (e) {
            case 'n' -> out.append('\n');
            case 'r' -> out.append('\r');
            case 't' -> out.append('\t');
            case 'b' -> out.append('\b');
            case 'f' -> out.append('\f');
            case 'u' -> {
               if (this.pos + 4 > this.text.length()) {
                  throw new IOException("bad unicode escape in JSON");
               }
               out.append((char)Integer.parseInt(this.text.substring(this.pos, this.pos + 4), 16));
               this.pos += 4;
            }
            default -> out.append(e);
         }
      }
   }

   private Object number() throws IOException {
      int start = this.pos;
      while (this.pos < this.text.length() && "+-0123456789.eE".indexOf(this.text.charAt(this.pos)) >= 0) {
         this.pos++;
      }
      if (start == this.pos) {
         throw new IOException("unexpected character in JSON");
      }
      String number = this.text.substring(start, this.pos);
      try {
         return number.contains(".") || number.contains("e") || number.contains("E") ? (Object)Double.valueOf(number) : (Object)Long.valueOf(number);
      } catch (NumberFormatException var4) {
         throw new IOException("bad number in JSON");
      }
   }
}
