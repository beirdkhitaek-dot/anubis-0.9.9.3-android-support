package net.anubis.client.security;

/** Unofficial Android port: the signed-release check is disabled because a modified jar cannot match the official signature. */
public final class OfficialBuild {
   private OfficialBuild() {
   }

   public static State state() {
      return State.NOT_CHECKED;
   }

   public static void checkBeforeLaunch() {
   }

   public static void enforceIfPending() {
   }

   public static void enforceOnFirstTick() {
   }

   public static enum State {
      PENDING,
      VERIFIED,
      MODIFIED,
      NOT_CHECKED;
   }
}
