package net.anubis.client.util.spotify;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/** Plain HttpURLConnection calls, which exist on every Java runtime including Android launchers. */
final class SpotifyHttp {
   private static final int MAX_BYTES = 4194304;

   record Reply(int status, byte[] body, String retryAfter) {
      String text() {
         return new String(this.body, StandardCharsets.UTF_8);
      }

      boolean ok() {
         return this.status >= 200 && this.status < 300;
      }
   }

   private SpotifyHttp() {
   }

   static Reply call(String method, String url, String bearer, String body, String contentType, int timeoutMs) throws IOException {
      URI uri = URI.create(url);
      String scheme = uri.getScheme() == null ? "" : uri.getScheme();
      if (!scheme.equals("https") && !scheme.equals("http")) {
         throw new IOException("unsupported URL scheme");
      }
      HttpURLConnection connection = (HttpURLConnection)uri.toURL().openConnection();
      try {
         connection.setConnectTimeout(timeoutMs);
         connection.setReadTimeout(timeoutMs);
         connection.setRequestMethod(method);
         connection.setInstanceFollowRedirects(true);
         connection.setRequestProperty("User-Agent", "AnubisSpotifyHud");
         if (bearer != null) {
            connection.setRequestProperty("Authorization", "Bearer " + bearer);
         }
         boolean writes = !method.equals("GET");
         if (writes) {
            byte[] data = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(data.length);
            if (contentType != null) {
               connection.setRequestProperty("Content-Type", contentType);
            }
            try (OutputStream out = connection.getOutputStream()) {
               out.write(data);
            }
         }
         int status = connection.getResponseCode();
         InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
         byte[] bytes = stream == null ? new byte[0] : read(stream);
         return new Reply(status, bytes, connection.getHeaderField("Retry-After"));
      } finally {
         connection.disconnect();
      }
   }

   static byte[] download(String url, int timeoutMs) throws IOException {
      Reply reply = call("GET", url, null, null, null, timeoutMs);
      return reply.status() == 200 ? reply.body() : null;
   }

   private static byte[] read(InputStream stream) throws IOException {
      try (InputStream in = stream) {
         byte[] data = in.readNBytes(MAX_BYTES + 1);
         if (data.length > MAX_BYTES) {
            throw new IOException("response too large");
         }
         return data;
      }
   }
}
