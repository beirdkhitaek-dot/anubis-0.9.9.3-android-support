package net.anubis.client.util.spotify;

import java.util.Locale;

public interface PlayerSource {
   MediaSession.Snapshot poll();

   boolean togglePlayPause();

   boolean skipNext();

   boolean skipPrevious();

   String lastError();

   boolean isUnsupported();

   void close();

   static boolean supported() {
      return windows() || mac() || linux();
   }

   static PlayerSource spotify() {
      if (mac()) {
         return new MacSpotify();
      } else if (linux()) {
         // Android launchers report Linux but have no dbus, so they read Spotify through its web API instead.
         return (PlayerSource)(imgui.AnubisAndroidNative.isAndroidRuntime() ? new AndroidSpotify() : new LinuxSpotify());
      } else {
         return MediaSession.spotify();
      }
   }

   private static boolean windows() {
      return os().startsWith("windows");
   }

   private static boolean mac() {
      return os().startsWith("mac") || os().contains("darwin");
   }

   private static boolean linux() {
      return os().contains("linux");
   }

   private static String os() {
      return System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
   }
}
