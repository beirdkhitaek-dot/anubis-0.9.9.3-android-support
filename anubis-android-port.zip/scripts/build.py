#!/usr/bin/env python3
"""Builds the Anubis Android jar from an official Anubis jar plus the files in overlay/.

How it works:
  1. Finds the official jar in base/ (drop a new official jar there to update; the newest version wins).
  2. Checks that the inner parts of Anubis that the Android port depends on are unchanged
     (compat/base-hashes.json). If the developers changed them, it stops with a plain message.
  3. Compiles overlay-src with javac, copies the base jar without its signature, adds the Android files,
     sets the version and credits in fabric.mod.json and the manifest.

Version of the result = <official version>-android.<PORT_REVISION>, e.g. 1.0-android.1
Run from the repository root:  python3 scripts/build.py            (build)
                               python3 scripts/build.py --record   (save the compat hashes of the base jar)
"""
import glob
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE_DIR = os.path.join(ROOT, "base")
OVERLAY = os.path.join(ROOT, "overlay")
SRC = os.path.join(ROOT, "overlay-src")
BUILD = os.path.join(ROOT, "build", "classes")
DIST = os.path.join(ROOT, "dist")
HASHES = os.path.join(ROOT, "compat", "base-hashes.json")

# Entries of the base jar that must not be copied over.
DROP_PREFIXES = ("META-INF/ANUBIS.",)                       # signature files
DROP_EXACT = {"META-INF/MANIFEST.MF", "fabric.mod.json"}   # rewritten below
REPLACED_PREFIX = "net/anubis/client/security/OfficialBuild"  # rebuilt from overlay-src

BOOTSTRAP = "net.anubis.bootstrap.AnubisNativeBootstrap"
PORT_CREDIT = "Chukl (Android port)"

# Classes of the base jar that the Android parts build on, besides the ones the overlay replaces.
WATCH_PREFIXES = (
    "net/anubis/client/util/spotify/PlayerSource",
    "net/anubis/client/util/spotify/ScriptedPlayer",
    "net/anubis/client/util/spotify/LinuxSpotify",
    "net/anubis/client/util/spotify/MacSpotify",
    "net/anubis/client/util/spotify/MediaSession",
    "net/anubis/client/security/",
    "net/anubis/client/BuildConfig",
    "net/anubis/client/imgui/ImGuiManager",
    "net/anubis/client/input/AnubisKeyPolling",
)


def read(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def version_key(text):
    return [int(part) if part.isdigit() else 0 for part in re.split(r"[.\-+]", text.split("+")[0])]


def mod_json(jar_path):
    with zipfile.ZipFile(jar_path) as jar:
        return json.loads(jar.read("fabric.mod.json").decode("utf-8"))


def find_base_jar():
    jars = [p for p in glob.glob(os.path.join(BASE_DIR, "*.jar"))]
    if not jars:
        sys.exit("ERROR: no official Anubis jar found in the base/ folder. Upload the official jar there.")
    scored = []
    for path in jars:
        try:
            meta = mod_json(path)
        except Exception:
            continue
        if meta.get("id") == "anubisplus":
            scored.append((version_key(meta["version"]), path, meta))
    if not scored:
        sys.exit("ERROR: base/ has no jar that looks like the official Anubis jar (mod id anubisplus).")
    scored.sort(key=lambda item: item[0])
    return scored[-1][1], scored[-1][2]


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def watched_names(base, extra):
    names = set()
    for name in base.namelist():
        if name in extra or name.startswith(WATCH_PREFIXES):
            if name.endswith(".class"):
                names.add(name)
    # the bundled ImGui library files must stay the same version too
    names.update(n for n in base.namelist() if n.startswith("META-INF/jars/imgui-java-"))
    return sorted(names)


def compile_sources(base_jar):
    os.makedirs(BUILD, exist_ok=True)
    sources = [os.path.join(SRC, name) for name in sorted(os.listdir(SRC)) if name.endswith(".java")]
    classpath = os.pathsep.join([base_jar, OVERLAY])
    subprocess.run(
        ["javac", "--release", "21", "-proc:none", "-Xlint:-classfile", "-cp", classpath, "-d", BUILD] + sources,
        check=True,
    )


def collect_extra():
    """Return {jar path: file path} for everything added on top of the base jar."""
    extra = {}
    for folder in (OVERLAY, BUILD):
        for root, _dirs, files in os.walk(folder):
            for name in files:
                full = os.path.join(root, name)
                extra[os.path.relpath(full, folder).replace(os.sep, "/")] = full
    return extra


def check_compat(base, extra):
    """Stop if the official jar changed the parts the Android port depends on."""
    if not os.path.exists(HASHES):
        print("note: no compat/base-hashes.json, skipping the compatibility check")
        return
    with open(HASHES, encoding="utf-8") as handle:
        known = json.load(handle)["hashes"]
    changed = []
    for name, want in known.items():
        if name not in base.namelist():
            changed.append(f"{name} (missing)")
        elif sha256_bytes(base.read(name)) != want:
            changed.append(name)
    if changed:
        print("ERROR: this Anubis update changed parts that the Android port depends on:")
        for name in changed[:30]:
            print("  - " + name)
        sys.exit(
            "The port needs a fix before it can be built for this version. "
            "Nothing was published. Send the new official jar and this message to whoever maintains the port."
        )
    print(f"compatibility check passed ({len(known)} files match)")


def record():
    path, _meta = find_base_jar()
    compile_sources(path)
    extra = collect_extra()
    with zipfile.ZipFile(path) as base:
        names = watched_names(base, extra)
        hashes = {n: sha256_bytes(base.read(n)) for n in names}
    os.makedirs(os.path.dirname(HASHES), exist_ok=True)
    with open(HASHES, "w", encoding="utf-8") as handle:
        json.dump({"recorded_from": os.path.basename(path), "hashes": hashes}, handle, indent=1, sort_keys=True)
    print(f"recorded {len(hashes)} hashes from {os.path.basename(path)}")


def main():
    if "--record" in sys.argv:
        return record()

    base_path, meta = find_base_jar()
    old_version = meta["version"]                      # e.g. 1.0+mc1.21.11
    base_ver, _, mc_tag = old_version.partition("+")
    mc_tag = mc_tag or "mc1.21.11"
    revision = read(os.path.join(ROOT, "PORT_REVISION"), "1")
    update = read(os.path.join(ROOT, "UPDATE_NAME"), "Android port")
    version = f"{base_ver}-android.{revision}"         # e.g. 1.0-android.1
    mod_version = f"{base_ver}+{mc_tag}-android.{revision}"
    jar_name = f"Anubis_{version}.jar"
    print(f"base jar: {os.path.basename(base_path)} (official version {old_version})")

    compile_sources(base_path)
    extra = collect_extra()
    os.makedirs(DIST, exist_ok=True)
    out_path = os.path.join(DIST, jar_name)
    for old in glob.glob(os.path.join(DIST, "*.jar")):
        os.remove(old)

    with zipfile.ZipFile(base_path) as base:
        check_compat(base, extra)
        manifest = base.read("META-INF/MANIFEST.MF").decode("utf-8")
        main_section = re.split(r"\r?\n\r?\n", manifest, maxsplit=1)[0].replace(old_version, mod_version)

        meta["version"] = mod_version
        meta["name"] = "Anubis (Android port)"
        authors = list(meta.get("authors", []))
        if PORT_CREDIT not in authors:
            authors.append(PORT_CREDIT)
        meta["authors"] = authors
        meta["description"] = (meta.get("description", "").rstrip() + " Android port by Chukl.").strip()
        launch = [e for e in meta["entrypoints"].get("preLaunch", []) if e != BOOTSTRAP]
        meta["entrypoints"]["preLaunch"] = [BOOTSTRAP] + launch

        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as out:
            out.writestr("META-INF/MANIFEST.MF", main_section + "\r\n\r\n")
            out.writestr("fabric.mod.json", json.dumps(meta, indent=2))
            for info in base.infolist():
                name = info.filename
                if name in DROP_EXACT or name.startswith(DROP_PREFIXES) or name.startswith(REPLACED_PREFIX):
                    continue
                if name in extra:
                    continue  # replaced by the overlay
                out.writestr(info, base.read(name))
            for name in sorted(extra):
                out.write(extra[name], name)

    with open(out_path, "rb") as handle:
        digest = hashlib.sha256(handle.read()).hexdigest()

    notes = f"""# Anubis {version} - {update}

Unofficial Android port of **Anubis {base_ver}** (Minecraft {mc_tag[2:]}, Fabric). Mod version in game: `{mod_version}`.
**Android port by Chukl.** Anubis itself is made by its original developers (4ldenz and team).

## What is different from the official jar
- Adds the arm64 ImGui library and the Android startup code, so the Anubis menu loads on Android launchers such as Zalith.
- Adds the Android input handling and file picker.
- Spotify HUD works on Android. Free way: it reads what Spotify is playing through Last.fm (connect Spotify to a free Last.fm account, then enter your Last.fm name and API key at `127.0.0.1:8888` in your phone's browser). Optional: Spotify's own web API, which needs Premium on the developer app and adds play/pause/skip and the song position.
- The signed-release check is turned off, because any modified jar fails it.

This build is **not signed and not made by the Anubis developers**. Anubis is GPL-3.0; the source for this port is in this repository.

## Install
Delete the old Anubis jar from your mods folder and put `{jar_name}` in.

SHA-256: `{digest}`
"""
    with open(os.path.join(DIST, "release-notes.md"), "w", encoding="utf-8") as handle:
        handle.write(notes)
    with open(os.path.join(DIST, "release-title.txt"), "w", encoding="utf-8") as handle:
        handle.write(f"Anubis {version} - {update}\n")
    with open(os.path.join(DIST, "version.txt"), "w", encoding="utf-8") as handle:
        handle.write(version + "\n")
    print(f"built {out_path} ({os.path.getsize(out_path)} bytes)")
    print(f"sha256 {digest}")


if __name__ == "__main__":
    sys.exit(main())
